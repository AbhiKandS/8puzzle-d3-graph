import Astar from "./Astar.js";
import { BLANK, PuzzleState } from "./puzzle_state.js";

let newstate = new PuzzleState(
    [['1', '2', '3'],
    [ '7', '4', '6'],
    [BLANK, '5', '8']]
)

Astar(newstate).renderToTree();