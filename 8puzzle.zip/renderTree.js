import "./d3.v7.min.js";

export default function renderTree(data) {
    const svg = d3.select("#tree");
    const root = d3.hierarchy(data);


    const maxDepth = root.height + 1;
    const numNodes = root.descendants().length;
    const treeWidth = numNodes * 100;  // tune multiplier as needed
    const treeHeight = maxDepth * 200;


    svg.attr("width", treeWidth)
        .attr("height", treeHeight);
    const treeLayout = d3.tree().size([treeWidth - 100, treeHeight - 100]);
    treeLayout(root);

    svg.selectAll('line')
        .data(root.links())
        .join('line')
        .attr('x1', d => d.source.x + 50)
        .attr('y1', d => d.source.y + 50)
        .attr('x2', d => d.target.x + 50)
        .attr('y2', d => d.target.y + 50)
        .attr('stroke', '#555');

    svg.selectAll('rect')
        .data(root.descendants())
        .join('rect')
        .attr('x', d => d.x + 10)
        .attr('y', d => d.y + 20)
        .attr('width', 75)
        .attr('height', 75)
        .attr('rx', 10)
        .attr('ry', 10)
        .attr('fill', 'lightblue')
        .attr('stroke', '#333');


    // Add labels
    svg.selectAll('text')
        .data(root.descendants())
        .join('text')
        .attr('x', d => d.x + 50)
        .attr('y', d => d.y + 50)
        .attr('text-anchor', 'middle')
        .selectAll('tspan')
        .data(d => d.data.name.split('\n')) // split lines
        .join('tspan')
        .attr('x', (d, i, nodes) => {
            const parent = d3.select(nodes[i].parentNode).datum();
            return parent.x + 50;
        })
        .attr('dy', (d, i) => i === 0 ? 0 : 15) // vertical spacing
        .text(d => d);

    console.log('done');


}