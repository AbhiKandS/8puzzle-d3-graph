import MinHeap from "./minHeap.js";
import { BLANK, PuzzleState } from "./puzzle_state.js";


export default function Astar(puzzleState=newstate) {
    const visited = new Set();
    const pq = new MinHeap();

    pq.push({state: puzzleState, priority: puzzleState.h_cost});
    visited.add(puzzleState.name);

    let currState;
    //TODO: implement isSolvable
    while (!pq.isEmpty()) {
        currState = pq.pop().state;
        if (currState.h_cost == 0) {
            console.log('done');

            currState.solved();
            return puzzleState;
        }

        visited.add(currState.name);
        currState.expandChildren();
        // currState.printChildren();

        for (const child of currState.children)
            if (!visited.has(child.name))
                pq.push({state: child, priority: child.h_cost});
    }
    console.log("unsolvable");
    return puzzleState.unsolved();
}